public class Circulo extends Figura2D{
    
}
