public class Figura2D extends Figura{
    
}
