public class Quadrado extends Quadrilatero{
    
}
