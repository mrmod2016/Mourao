public class Esfera extends Figura3D{
    
}
