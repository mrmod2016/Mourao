public class Cobra extends Oviparo{
    public Cobra(String nome,String botaOvos, int qtdOvos){
        super(nome,botaOvos,qtdOvos);
    }
}
