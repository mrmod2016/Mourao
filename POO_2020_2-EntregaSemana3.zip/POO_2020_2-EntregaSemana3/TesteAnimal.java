public class TesteAnimal {
    public static void main(String[] args) {
        Cachorro cachorro1 = new Cachorro("Spike");
        Gato gato1 = new Gato("frajola");        
    }
}
