public class Figura{
    
}