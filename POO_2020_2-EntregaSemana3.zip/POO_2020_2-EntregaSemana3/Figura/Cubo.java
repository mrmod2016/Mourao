public class Cubo extends Figura3D{
    
}
