public class Retangulo extends Quadrilatero{
    
}
