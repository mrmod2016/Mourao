public class Trapezio extends Quadrilatero{
    
}
