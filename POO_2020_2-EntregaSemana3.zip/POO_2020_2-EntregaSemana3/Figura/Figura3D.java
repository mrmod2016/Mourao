public class Figura3D extends Figura{
    
}
