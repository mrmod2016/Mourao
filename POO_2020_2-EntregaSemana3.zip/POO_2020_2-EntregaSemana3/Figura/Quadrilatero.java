public class Quadrilatero extends Figura2D{
    
}
