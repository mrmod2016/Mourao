public class Gato extends Mamifero{
    public Gato(String nome){
        super(nome, 4);
        System.out.printf("Oi sou um gato, meu nome é: %s%n",nome);
    }
}
