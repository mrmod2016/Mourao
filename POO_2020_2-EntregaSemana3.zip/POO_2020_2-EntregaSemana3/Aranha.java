public class Aranha extends Oviparo{
    public Aranha(String nome,String botaOvos, int qtdOvos){
        super(nome,botaOvos, qtdOvos);
    }
}
