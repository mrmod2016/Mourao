public class Mamifero extends Animal{
    public Mamifero(String nome, int qtdPatas){
        this.setNome(nome);
        setQtdPatas(qtdPatas);
    }
}
