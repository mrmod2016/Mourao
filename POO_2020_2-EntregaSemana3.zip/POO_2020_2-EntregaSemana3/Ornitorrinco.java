public class Ornitorrinco extends Oviparo{
    public Ornitorrinco(String nome, int qtdPatas, String botaOvos, int qtdOvos){
        super(nome, qtdPatas, botaOvos, qtdOvos);
        //apesar de ser um mamífero ainda o consideramos como ovíparo
    }
}
